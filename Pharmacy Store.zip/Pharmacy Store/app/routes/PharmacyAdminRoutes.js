const multer = require("multer");
const router = require('express').Router();
const controller = require('../http/controller/PharmacyController');

const Auth = require("../http/middleware/Auth")
const PharmacyAdmin = require("../http/middleware/PharmacyAdmin")

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/')
    },
    filename: function (req, file, cb) {
        cb(null,  Date.now()+"-"+file.originalname)
    }
})
   
var upload = multer({ storage: storage })

router.post('/login', controller.login);

router.post("/medicines/addMedicine",[Auth,PharmacyAdmin/*,upload.single("medicinePhoto")*/],controller.addMedicine)
router.delete("/medicines/deleteMedicine/:medicineId",[Auth,PharmacyAdmin],controller.deleteMedicine)
router.put("/medicines/updateMedicine/:medicineId",[Auth,PharmacyAdmin],controller.updateMedicine)
router.get("/medicines/getMedicineList",[Auth,PharmacyAdmin],controller.getMedicineList)


module.exports = router;
