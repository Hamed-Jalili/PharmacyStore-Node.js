const Joi = require('joi');
Joi.objectId = require('joi-objectid')(Joi);

const validateCreatePharmacy = (data) => {
  const schema = Joi.object({
    name: Joi.string().required(),
    description: Joi.string().required(),
    address: Joi.string(),
    adminUsername: Joi.string().required(),
    adminPassword: Joi.string().required(),
  });
  return schema.validate(data);
};

const validateUpdatePharmacy = (data) => {
  const schema = Joi.object({
    name: Joi.string(),
    description: Joi.string(),
    address: Joi.string(),
    adminUsername: Joi.string(),
    adminPassword: Joi.string(),
  });
  return schema.validate(data);
};

const loginValidator = (data) => {
  const schema = Joi.object({
    username: Joi.string().required(),
    password: Joi.string().required(),
  });
  return schema.validate(data);
};


const medicineValidator = (data) => {
  const schema = Joi.object({
    name:Joi.string().required(),
    description:Joi.string().required(),
    price:Joi.number().required()
  });
  return schema.validate(data);
};


module.exports = { validateCreatePharmacy: validateCreatePharmacy,validateUpdatePharmacy: validateUpdatePharmacy,loginValidator,medicineValidator: medicineValidator };
