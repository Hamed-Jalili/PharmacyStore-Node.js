const PharmacyModel = require('../../models/Pharmacy');
const _ = require('lodash');
const bcrypt = require('bcrypt');
const {
  validateCreatePharmacy,
  validateUpdatePharmacy,
  loginValidator,
  medicineValidator
} = require('../validator/PharmacyValidator');
const { rest } = require('lodash');

class PharmacyController {
  async getList(req, res) {
    const list = await PharmacyModel.find()
      .select('name description score adminUsername pic address')
      .limit(20);
    res.send(list);
  }
  async getListForUser(req, res) {
    const list = await PharmacyModel.find()
      .select('name description score pic address')
      .limit(20);
    res.send(list);
  }
  async getOne(req, res) {
    const id = req.params.id;
    const data = await PharmacyModel.findById(id).select('-adminPassword');
    if (!data) return res.status(404).send('not found');
    res.send(data);
  }
  async getOneForUser(req, res) {
    const id = req.params.id;
    const data = await PharmacyModel.findById(id).select('-adminPassword -adminUsername');
    if (!data) return res.status(404).send('not found');
    res.send(data);
  }

  async addCommentToPharmacy(req, res){
    const id = req.params.id;
    const data = await PharmacyModel.findById(id);
    if(!data) return res.status(400).send("داروخانه مربوطه پیدا نشد")

    const body = {
      user : req.body.user,
      text : req.body.text,
      score : req.body.score
    }
    data.comment.push(body)
    await data.save();
    res.send(true);
  }

  async create(req, res) {
    const { error } = validateCreatePharmacy(req.body);
    if (error) return res.status(400).send(error.message);
    let pharmacy = new PharmacyModel(
      _.pick(req.body, [
        'name',
        'description',
        'address',
        'adminUsername',
        'adminPassword',
      ]),
    );
    const salt = await bcrypt.genSalt(10);
    pharmacy.adminPassword = await bcrypt.hash(
      pharmacy.adminPassword,
      salt,
    );
    pharmacy = await pharmacy.save();
    res.send(pharmacy);
  }
  async update(req, res) {
    const id = req.params.id;
    const { error } = validateUpdatePharmacy(req.body);
    if (error) return res.status(400).send(error.message);
    const result = await PharmacyModel.findByIdAndUpdate(id, {
      $set: _.pick(req.body, [
        'name',
        'description',
        'address',
        'adminUsername',
        'adminPassword',
      ]),
    },{new : true});
    if (!result) return res.status(404).send('not found');
    res.send(
      _.pick(result, [
        'name',
        'description',
        'address',
        'adminUsername',
        'adminPassword',
      ]),
    );
  }
  async delete(req, res) {
    const id = req.params.id;
    const result = await PharmacyModel.findByIdAndRemove(id);
    res.status(200).send("مدیریت مورد نظر با موفقیت حذف گردید");
  }

  async login(req,res){
    const { error } = loginValidator(req.body);
    if (error) return res.status(400).send({ message: error.message });

    let pharmacy = await PharmacyModel.findOne({ adminUsername: req.body.username });
    if (!pharmacy)
      return res
        .status(400)
        .send({ message: 'داروخانه ای با این نام کاربری یا پسورد یافت نشد' });

    const result = await bcrypt.compare(req.body.password, pharmacy.adminPassword);
    if (!result)
      return res
        .status(400)
        .send({ message: 'داروخانه ای با این نام کاربری یا پسورد یافت نشد' });

    const token = pharmacy.generateAuthToken();
    res.header("Access-Control-Expose-headers","x-auth-token").header('x-auth-token', token).status(200).send({ success: true });

  }
  

  async addMedicine(req, res){
    console.log(req.file);
    const pharmacy = await PharmacyModel.findOne({adminUsername : req.user.username });
    if(!pharmacy) return res.status(404).send("داروخانه مربوطه پیدا نشد");
    const {error }= medicineValidator(req.body);
    if(error) return res.status(400).send(error.message);
    pharmacy.menu.push(_.pick(req.body,["name","description","price"]));//,pic : req.file.path});
    await pharmacy.save();
    res.send(true);
  }

  async deleteMedicine(req, res){
    const pharmacy = await PharmacyModel.findOne({adminUsername : req.user.username });
    if(!pharmacy) return res.status(404).send("داروخانه مربوطه پیدا نشد");
    const medicineId = req.params.medicineId;
    const foundMedicine = pharmacy.menu.id(medicineId);
    if(foundMedicine)
      foundMedicine.remove();
    await pharmacy.save();
    res.send(true);
  }

  async updateMedicine(req, res){
    const pharmacy = await PharmacyModel.findOne({adminUsername : req.user.username });
    if(!pharmacy) return res.status(404).send("داروخانه مربوطه پیدا نشد");
    const medicineId = req.params.medicineId;
    const foundMedicine = pharmacy.menu.id(medicineId);
    if(foundMedicine)
     {
       if(req.body.name)
        foundMedicine.name = req.body.name;
        if(req.body.description)
        foundMedicine.description = req.body.description;
        if(req.body.price)
        foundMedicine.price = req.body.price;
     }
    await pharmacy.save();
    res.send(true);
  }

  async getMedicineList(req, res){
    const pharmacy = await PharmacyModel.findOne({adminUsername : req.user.username });
    if(!pharmacy) return res.status(404).send("داروخانه مربوطه پیدا نشد");
    res.send(pharmacy.menu);
  }
  
  //async setMedicinePhoto(req, res){
   // console.log(req.file);
   // res.send(req.file)
 // }

}

module.exports = new PharmacyController();
