const App = require('./app');

new App();
